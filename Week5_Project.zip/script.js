const STORAGE_KEY="taskflow-tasks-v1"; const THEME_KEY="taskflow-theme-v1";
const seed=[{id:1,title:"Review project requirements",category:"Planning",done:true},{id:2,title:"Build responsive dashboard",category:"Development",done:true},{id:3,title:"Test keyboard navigation",category:"Research",done:false},{id:4,title:"Polish mobile layout",category:"Design",done:false}];
let tasks=JSON.parse(localStorage.getItem(STORAGE_KEY)||"null")||seed;
const $=s=>document.querySelector(s);
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(tasks));}
function render(){
 const query=$("#search").value.trim().toLowerCase(), filter=$("#filter").value;
 const visible=tasks.filter(t=>(filter==="all"||(filter==="done"?t.done:!t.done))&&t.title.toLowerCase().includes(query));
 $("#taskList").replaceChildren();
 visible.forEach(task=>{
  const node=$("#taskTemplate").content.cloneNode(true), item=node.querySelector(".task-item");
  if(task.done)item.classList.add("done");
  item.querySelector("h3").textContent=task.title; item.querySelector(".category").textContent=task.category;
  const check=item.querySelector(".check"); check.setAttribute("aria-label",task.done?"Mark task active":"Mark task complete");
  check.addEventListener("click",()=>{task.done=!task.done;save();render();});
  item.querySelector(".delete").addEventListener("click",()=>{tasks=tasks.filter(x=>x.id!==task.id);save();render();});
  $("#taskList").appendChild(node);
 });
 $("#emptyState").hidden=visible.length!==0;
 const total=tasks.length, done=tasks.filter(t=>t.done).length, active=total-done, pct=total?Math.round(done/total*100):0;
 $("#totalCount").textContent=total;$("#doneCount").textContent=done;$("#activeCount").textContent=active;$("#percentCount").textContent=pct+"%";
 $("#progressText").textContent=pct+"%";$("#progressBar").style.width=pct+"%";
}
function updateClock(){const d=new Date();$("#today").textContent=d.toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"});$("#clock").textContent=d.toLocaleTimeString(undefined,{hour:"2-digit",minute:"2-digit"});}
$("#search").addEventListener("input",render);$("#filter").addEventListener("change",render);
const dialog=$("#taskDialog"), form=$("#taskForm");
$("#addTaskBtn").addEventListener("click",()=>{form.reset();dialog.showModal();$("#taskTitle").focus();});
$("#closeDialog").addEventListener("click",()=>dialog.close());$("#cancelDialog").addEventListener("click",()=>dialog.close());
form.addEventListener("submit",e=>{e.preventDefault();const title=$("#taskTitle").value.trim();if(!title)return;tasks.unshift({id:Date.now(),title,category:$("#taskCategory").value,done:false});save();render();dialog.close();});
const savedTheme=localStorage.getItem(THEME_KEY); if(savedTheme==="dark")document.body.classList.add("dark");
$("#themeToggle").addEventListener("click",()=>{document.body.classList.toggle("dark");localStorage.setItem(THEME_KEY,document.body.classList.contains("dark")?"dark":"light");});
render();updateClock();setInterval(updateClock,30000);
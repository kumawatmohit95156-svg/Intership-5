# Week 5 — Final Project Integration: Mini Web Application

TaskFlow is a small responsive task-management dashboard built with HTML, CSS, and vanilla JavaScript.

## Features
- Dynamic task list with seeded data
- Add, complete/uncomplete, delete tasks
- Search and status filtering
- Live total/completed/active/completion statistics
- Progress bar that updates from current data
- Light/dark theme preference
- LocalStorage persistence for tasks and theme
- Responsive desktop/tablet/mobile layout
- Semantic controls, labels, focus styles and live task-list feedback
- Accessible modal dialog for adding tasks

## Run
Extract the ZIP and open `index.html` in a modern browser. No build tools or third-party JavaScript libraries are required.

## Testing
1. Add a task and verify the dashboard statistics update.
2. Complete a task and check the progress percentage.
3. Search and filter tasks.
4. Delete a task and reload the page; LocalStorage should preserve the state.
5. Toggle dark mode and reload.
6. Test all controls using Tab, Enter and Space.
7. Resize to mobile width and confirm the layout remains usable.

## Technology
HTML5, CSS3, JavaScript (ES6+), LocalStorage API, native dialog element.
